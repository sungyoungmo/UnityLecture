using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Red : ButtonPress
{
    protected override void setColor()
    {
        base.setColor();
    }

    protected override void setPosition()
    {
        base.setPosition();
    }

    public void buttonPlay()
    {
        setColor();
        setPosition();
    }


}
