public interface IInteractable
{
    public void Interact();
}