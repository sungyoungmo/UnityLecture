public interface IHitable
{

    public void Hit(float damage);


}