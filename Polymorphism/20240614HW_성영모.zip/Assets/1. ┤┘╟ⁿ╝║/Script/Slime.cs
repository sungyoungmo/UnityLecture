using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Slime : Monster
{

    private void Start()
    {
        maxHp = currentHP = 100;
    }
}
